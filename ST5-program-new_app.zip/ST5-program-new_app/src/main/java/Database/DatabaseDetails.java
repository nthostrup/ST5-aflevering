package Database;

public class DatabaseDetails {
	
	final static protected String username = "hst_2019_19gr5403";
	final static protected String password = "oorurohxahzuuzuceeth";
	final static protected String host = "jdbc:mysql://db.course.hst.aau.dk:3306/hst_2019_19gr5403?serverTimezone=UTC";
	

}
